public class Menu{
	public int menuPrice;
	public String menuCode;
	public String menuName;
	
	public Menu(String menuCode, String menuName, int menuPrice) {
		this.menuCode = menuCode;
		this.menuName = menuName;
		this.menuPrice = menuPrice;
	}
	
}