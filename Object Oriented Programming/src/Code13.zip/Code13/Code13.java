// DIFFERENCE PACKAGE

// Caller Class
import Folder.Code13a;
import Folder.Folder2.Code13b;

class Code13
{
	public static void main(String [] args)
	{
		String [] strarr = new String [1];
		strarr[0]="hello world";

		Code13a O13a = new Code13a();
		Code13b O13b = new Code13b();

		O13a.main(strarr);
		O13a.test13a();
		O13a.accessCode13a_1();

		System.out.println("");

		O13b.main(strarr);
		O13b.test13b();
		O13b.accessCode13b_1();
	}
}