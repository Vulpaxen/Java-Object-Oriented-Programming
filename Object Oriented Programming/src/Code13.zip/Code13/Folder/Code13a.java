package Folder;
// Called Class(es)

class Code13a_1
{
	public static void main(String [] args)
	{
		System.out.println("Ini public static void main di Code13a_1, parameter args[0] : "+args[0]);
	}

	public void test13a_1()
	{
		System.out.println("Ini void test13a di Code13a_1");
	}
}

public class Code13a
{
	public static void main(String [] args)
	{
		System.out.println("Ini public static void main di Code13a, parameter args [0] : "+args[0]);
	}

	public void test13a()
	{
		System.out.println("Ini void test13a di Code13a");
	}

	public void accessCode13a_1()
	{
		Code13a_1 O13a_1  = new Code13a_1();
		String [] strarr = new String [1];
		strarr[0]="hello world";

		O13a_1.main(strarr);
		O13a_1.test13a_1();
	}
}