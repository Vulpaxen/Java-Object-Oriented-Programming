// Called Class(es)
package Folder.Folder2;

class Code13b_1
{
	public static void main(String [] args)
	{
		System.out.println("Ini public static void main di Code13b_1, parameter args[0] : "+args[0]);
	}

	public void test13b_1()
	{
		System.out.println("Ini void test13b di Code13b_1");
	}
}

public class Code13b
{
	public static void main(String [] args)
	{
		System.out.println("Ini public static void main di Code13b, parameter args [0] : "+args[0]);
	}

	public void test13b()
	{
		System.out.println("Ini void test13b di Code13b");
	}

	public void accessCode13b_1()
	{
		Code13b_1 O13b_1  = new Code13b_1();
		String [] strarr = new String [1];
		strarr[0]="hello world";

		O13b_1.main(strarr);
		O13b_1.test13b_1();
	}
}